import { Formik, Form } from "formik";
import { useCallback, useState } from "react";
import * as yup from "yup";
import FormField from "./components/FormField";

const initialValues = {
  name: "",
  index: -1
};
const validationSchema = yup.object().shape({
  name: yup.string().label("Name"),
  index: yup.number().label("Index")
});

const App = () => {
  const addform = (index) => {
    itemsGroup[index].showForm = true;
    console.log(itemsGroup);
    setItemsGroup([...itemsGroup]);
  };
  const [itemsGroup, setItemsGroup] = useState([]);
  const handleSubmit = useCallback(async ({ name }, { resetForm }, index) => {
    if (itemsGroup[index].showFormModeedit) {
      const indexItem = itemsGroup[index].items.indexOf(
        itemsGroup[index].itemsToDelete[0]
      );
      itemsGroup[index].items[indexItem].name = name;
      itemsGroup[index].itemsToDelete = [];
      itemsGroup[index].showFormModeedit = false;
    } else {
      itemsGroup[index].items = [
        ...itemsGroup[index].items,
        {
          name
        }
      ];
    }

    console.log(name, index);

    resetForm();
    itemsGroup[index].showForm = false;
    setItemsGroup([...itemsGroup]);

    return;
  }, []);
  const deletelist = (indexItem, index) => {
    const newItems = [...itemsGroup[index].items];
    newItems.splice(indexItem, 1);
    itemsGroup[index].items = newItems;
    setItemsGroup([...itemsGroup]);
    console.log("delete");
  };
  const delall = (index) => {
    console.log(index);
    console.log(itemsGroup[index].itemsToDelete);
    itemsGroup[index].items = itemsGroup[index].items.filter(
      (item) => !itemsGroup[index].itemsToDelete.includes(item)
    );
    itemsGroup[index].itemsToDelete = [];
    setItemsGroup([...itemsGroup]);
  };
  const itemtoDelete = (indexItem, index, event) => {
    const indexfound = itemsGroup[index].itemsToDelete.indexOf(
      itemsGroup[index].items[indexItem]
    );
    indexfound === -1
      ? itemsGroup[index].itemsToDelete.push(itemsGroup[index].items[indexItem])
      : itemsGroup[index].itemsToDelete.splice(indexfound, 1);
    setItemsGroup([...itemsGroup]);
  };

  const displayTabContent = (index) => {
    itemsGroup[index].displayContent = true;
    for (let i = 0; i < itemsGroup.length; i += 1) {
      if (i !== index) {
        itemsGroup[i].displayContent = false;
      }
    }
    setItemsGroup([...itemsGroup]);
  };
  let [showFormNewList, setShowFormNewList] = useState();
  const initialValuesNewList = {
    name: ""
  };
  const validationSchemaNewList = yup.object().shape({
    name: yup.string().label("Name")
  });

  const handleSubmitNewList = useCallback(
    async ({ name }, { resetForm }, index) => {
      itemsGroup.push({
        title: name,
        items: [],
        showForm: false,
        itemsToDelete: [],
        displayContent: false,
        showFormModeedit: false
      });
      if (itemsGroup.length === 1) {
        itemsGroup[0].displayContent = true;
      }
      setItemsGroup([...itemsGroup]);
      setShowFormNewList(false);

      resetForm();

      return;
    },
    []
  );

  const addNewList = () => {
    setShowFormNewList(true);
  };
  const edit = (index) => {
    const itemsToDelete = itemsGroup[index].itemsToDelete;
    if (itemsToDelete.length !== 1) {
      return;
    }
    itemsGroup[index].showForm = true;
    itemsGroup[index].showFormModeedit = true;
    setItemsGroup([...itemsGroup]);
  };
  return (
    <>
      {itemsGroup.map(({ title, displayContent, showForm, items }, index) => (
        <div className="tabs" key={title + index}>
          <ul className="tab-list">
            <button
              className="bg-green-400 border-4 border-black flex: row "
              onClick={() => displayTabContent(index)}
            >
              {title}
            </button>
          </ul>
          {displayContent ? (
            <div className="tab-content">
              <nav className="bg-blue-400">
                <button className="px-4" onClick={() => addform(index)}>
                  +
                </button>
                <button className="px-4" onClick={() => edit(index)}>
                  edit
                </button>
                <button className="px-4" onClick={() => delall(index)}>
                  del
                </button>
              </nav>

              {showForm ? (
                <Formik
                  initialValues={initialValues}
                  onSubmit={(values, resetForm) =>
                    handleSubmit(values, resetForm, index)
                  }
                  validationSchema={validationSchema}
                >
                  {({ isValid, touched }) => (
                    <Form className="flex flex-col gap-4 p-4">
                      <FormField name="name" label="Name" />

                      <button
                        type="submit"
                        className="bg-blue-600 active:bg-blue-700 disabled:bg-slate-400 text-white font-semibold px-2 py-1"
                      >
                        +
                      </button>
                    </Form>
                  )}
                </Formik>
              ) : null}
              <ul>
                {items.map(({ name }, itemIndex) => (
                  <li
                    key={name + itemIndex}
                    className="p-4 first:border-t border-b"
                  >
                    <input
                      type="checkbox"
                      onClick={(e) => itemtoDelete(itemIndex, index)}
                    />
                    {name}
                    <button
                      className="float-right bg-red-400"
                      onClick={() => deletelist(itemIndex, index)}
                    >
                      trash
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>
      ))}
      <button className="border-4 bg-blue-400" onClick={addNewList}>
        newlist
      </button>
      {showFormNewList ? (
        <Formik
          initialValues={initialValuesNewList}
          onSubmit={(values, resetForm) =>
            handleSubmitNewList(values, resetForm)
          }
          validationSchema={validationSchemaNewList}
        >
          {() => (
            <Form className="flex flex-col gap-4 p-4">
              <FormField name="name" label="Name" />

              <button
                type="submit"
                className="bg-blue-600 active:bg-blue-700 disabled:bg-slate-400 text-white font-semibold px-2 py-1"
              >
                +
              </button>
            </Form>
          )}
        </Formik>
      ) : null}
    </>
  );
};

export default App;
